# 15/04 last prompt change. 

import asyncio

import ollama
import time
import functools

import pathlib
import pandas as pd
from datetime import datetime

import json
import re

#model configuration params
model_name = "llama3.2:3b"
model_config = "llama"

CONFIG = {
    "llama": {
            "num_gpu": 1,
            "temperature": 0.1,    # Low value to reduce creativity and hallucinations
            "top_p": 0.9,          # Limit diversity of considered tokens
            "top_k": 40,           # Token filtering for better responses
            "seed": 42,            # Set a consistent seed
            "repeat_penalty": 1.1, # Penalizes repetitions (Llama responds well to 1.1)
            "num_ctx": 8192,       # Llama 3.1 supports larger context windows
            "num_predict": 2048,   # Maximum tokens to generate
            "num_thread": 8        # Optimize threading for larger model
    },
    "gemma": {
        "num_gpu": 1,
        "temperature": 0.1,  # Low value to reduce creativity and allucinations
        "top_p": 0.9,        # Limit diversity of considered tokens
        "seed": 42,          # Set a consistent seed
        "repeat_penalty": 1.2 # penalizes restrictions to aid consistency
        #"num_ctx": 4096      # Match context window size
    },
    "deepseek": {
        "num_gpu": 1,
        "temperature": 0.1,    # Keep low for factual responses
        "top_p": 0.9,          # Good value for DeepSeek-V2
        "top_k": 50,           # DeepSeek-V2 benefits from slightly higher top_k
        "seed": 42,            # Keep for consistency
        "repeat_penalty": 1.1, # Slightly lower - DeepSeek-V2 handles repetition well
        "num_ctx": 32768,      # DeepSeek-V2 supports much larger context (32K tokens)
        "num_predict": 4096    # Can generate longer responses with V2
    }
}

##Time function
def timer(func):
    """
    A decorator that measures and prints the execution time of a function.
    
    Args:
        func: The function to be timed
        
    Returns:
        wrapper: The wrapped function that includes timing functionality
    """
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        # Record start time
        start_time = time.perf_counter()
        
        # Execute the function
        result = func(*args, **kwargs)
        
        # Record end time
        end_time = time.perf_counter()
        
        # Calculate duration
        duration = end_time - start_time
        
        # Print execution time
        #print(f"Function '{func.__name__}' took {duration:.4f} seconds to execute")
        
        return result,duration
    return wrapper


async def generate_response(question):
    start_time = time.time()
    client = ollama.AsyncClient()
    response = await client.generate(model_name, question,options= CONFIG.get(model_config))

    end_time = time.time()
    duration = end_time - start_time
    
    return response['response'], duration

async def generate_argument_forlist(topic,index, filename):   
        #print(df_opinions['topic'])
        #print(topics_list)
        
        op1 = df_opinions.at[index,'op1'].replace('"', '\\"')
        op2 = df_opinions.at[index,'op2'].replace('"', '\\"')
        op3 = df_opinions.at[index,'op3'].replace('"', '\\"')

        opinions1 = f'"{op1}",\n"{op2}",\n"{op3}"'
 
        context = ''' 
The goal of this task is to evaluate the quality of the 2 arguments generated based on a set of opinions about a specific climate change topic. Check the structure and effectiveness of the arguments, not their factual validity. The arguments should logically align with the provided opinions and demonstrate clear reasoning. 

Assign a score from 1 (worst) to 5 (best) to each argument based on the following criteria:
Score: 1 - The argument is poorly structured, incoherent, or unrelated to the opinions.
Score: 2 - The argument is weakly connected to the opinions and lacks clarity or logic.
Score: 3 - The argument is somewhat structured but has minor flaws in logic or relevance.
Score: 4 - The argument is well-structured, logical, and mostly aligned with the opinions.
Score: 5 - The argument is excellent: clear, logical, and fully aligned with the opinions.

Return your output in JSON format using the following structure:
Output = {
"Score": "[ score_for_argument_1, score_for_argument_2]",
"comments":"[comment_for_argument_1, comment_for_argument_2]"
}

This is an example
**Example Input:**
{
  "opinions": ["Rising global temperatures are causing more frequent and severe wildfires.", "Deforestation contributes to climate change by reducing the number of trees that absorb CO2.", "Governments should invest in reforestation programs to combat climate change."],
  "arguments": ["It is widely acknowledged that rising global temperatures are causing wildfires to become more frequent and severe, with the number of trees that absorb CO2 being significantly reduced due to deforestation. As a result, climate change is being exacerbated, and the restoration of carbon-absorbing trees through reforestation programs is seen as a necessary solution. It is urged that investments in such programs be made by governments to help mitigate the ongoing effects of climate change.","Climate change is bad because it makes the weather hotter and causes problems for animals."]
 }
**Output for the Example Input:**
{
  "scores":[5,2],
  "comments:" ["This argument is logically structured and connects the opinions effectively. It clearly links deforestation, wildfires, and the need for reforestation programs.",
  "This argument is vague and does not clearly connect to the provided opinions. It lacks specificity and logical structure"]
 }
------------------------------------------
Please punctuate the following arguments:
{
	"opinions":["
        '''   
        arg1 = df_opinions.at[index,'deepseek_0shot'].replace('"', '\\"')
        arg2 = df_opinions.at[index,'deepseek_1shot'].replace('"', '\\"')       
        arguments = '"arguments": [' + f'"{arg1}",\n"{arg2}"]'

        prompt = context + opinions1  + '''], ''' +  arguments + ''' }''' 
        #print(prompt)
        response,duration = await generate_response(prompt)
        #print(response)
                                
        return response,duration,prompt,op1,op2,op3

async def generate_argument(topic,index, filename):     
    response,duration,prompt,op1,op2,op3 = await generate_argument_forlist(topic,index, filename) 

    return response,duration,prompt,op1,op2,op3  

async def background_task():   
    #global repres_docs
    #global df_hier
    global file_name_complete
    global df_opinions
    global repres_docs_aux
    
    try:
        version='ver1'
        df_opinions = pd.read_csv('2round_arg_81_forJudge.csv') 
 
        filename = '_81_ScoresDS_'
        
        colum = ["topic","response", "prompt"]
        repres_docs_aux = pd.DataFrame(columns=colum)

        timestr = time.strftime("%Y%m%d-%H%M%S")
        # Resetear el índice  
        #df_hier = df_hier.reset_index(drop=True)
        file_name_complete = timestr + filename +version+'.csv'
        #la primer corrida se detuvo en la fila 56.
        for index, row in df_opinions.iterrows():
            topic = df_opinions.at[index, 'topic']
            #print(topic)
            
            response,duration,prompt,op1,op2,op3 = await generate_argument(topic,index,file_name_complete)
            # Wait a bit between requests to avoid overwhelming the API
            await asyncio.sleep(2)
                        
            # Create a new row for the DataFrame
            new_row = {
                        'timestamp': datetime.now(),
                        'topic': topic,
                        'prompt': prompt,
                        'response': response,
                        'duration': duration
            }
            repres_docs_aux = pd.concat([repres_docs_aux, pd.DataFrame([new_row])], ignore_index=True)
            repres_docs_aux.to_csv(file_name_complete, index=False)


        print('all responses processed.')
        repres_docs_aux.to_csv(file_name_complete, index=False)
    except Exception as e:
        print(e)
        print (topic)
        new_row = {"topic": topic, "response": '', "prompt": '', "duration":0}
        repres_docs_aux = pd.concat([repres_docs_aux, pd.DataFrame([new_row])], ignore_index=True)
        repres_docs_aux.to_csv(file_name_complete, index=False)

async def main():
    

    # Print info message
    print("Starting background Ollama processing...")
    print("Responses will be saved to csv file")

    # Run the background task
    await background_task()
    
if __name__ == '__main__':
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print('\nSaving final data and exiting...')
        # Ensure the DataFrame is saved before exit
        repres_docs_aux.to_csv(file_name_complete, index=False)
        print(f'Data saved to ' + file_name_complete)
        print('Goodbye!')